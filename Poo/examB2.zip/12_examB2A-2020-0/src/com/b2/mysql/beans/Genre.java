package com.b2.mysql.beans;

public enum Genre {
	Feminin, Masculin
}
